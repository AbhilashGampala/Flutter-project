import 'package:flutter_test/flutter_test.dart';
import 'package:somna/features/analytics/domain/analytics_calculator.dart';
import 'package:somna/shared/models/sleep_session.dart';

void main() {
  group('AnalyticsCalculator Tests', () {
    test('Empty sessions return empty stats', () {
      final summary = AnalyticsCalculator.calculateSummary([], 480);
      expect(summary.totalSessions, 0);
      expect(summary.totalSleepMinutes, 0);
      expect(summary.averageDurationMinutes, 0);
      expect(summary.longestSessionMinutes, 0);
      expect(summary.shortestSessionMinutes, 0);
      expect(summary.goalCompletionRate, 0.0);
    });

    test('Computes duration, extremes, and goal completion accurately', () {
      final now = DateTime(2026, 11, 9, 7, 0);

      final sessions = [
        // 8 hours = 480m (meets 480m goal)
        SleepSession(
          startTimestamp: now.subtract(const Duration(hours: 8)),
          endTimestamp: now,
        ),
        // 7 hours = 420m (under 480m goal)
        SleepSession(
          startTimestamp: now.subtract(const Duration(days: 1, hours: 7)),
          endTimestamp: now.subtract(const Duration(days: 1)),
        ),
        // 9 hours = 540m (meets 480m goal)
        SleepSession(
          startTimestamp: now.subtract(const Duration(days: 2, hours: 9)),
          endTimestamp: now.subtract(const Duration(days: 2)),
        ),
      ];

      final summary = AnalyticsCalculator.calculateSummary(sessions, 480);

      expect(summary.totalSessions, 3);
      expect(summary.totalSleepMinutes, 480 + 420 + 540); // 1440m
      expect(summary.averageDurationMinutes, 480);
      expect(summary.longestSessionMinutes, 540);
      expect(summary.shortestSessionMinutes, 420);
      expect(summary.sessionsMeetingGoal, 2);
      expect(summary.goalCompletionRate, closeTo(66.66, 0.1));
    });

    test('buildWeeklyChartData generates exactly 7 days', () {
      final now = DateTime(2026, 11, 9, 12, 0);
      final chartData = AnalyticsCalculator.buildWeeklyChartData([], referenceDate: now);

      expect(chartData.length, 7);
      // Last item should be today
      expect(chartData.last.date.day, now.day);
      expect(chartData.first.date.day, now.subtract(const Duration(days: 6)).day);
    });
  });
}

